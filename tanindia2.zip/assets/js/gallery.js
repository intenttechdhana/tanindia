(function ($) {
    const galleryRow = document.getElementById("galleryRow");

    const exts = ["jpg","png","jpeg","webp"];

    function loadImages() {
      let fragment = document.createDocumentFragment();
      let pending = 0;
      for (let i = 1; i <= TOTAL; i++) {
        pending++;
        detectAndAppend(i).finally(() => {
          pending--;
          // once all detection finished, ensure magnific is initialized
          if (pending === 0) initMagnific();
        });
      }
    }

    function detectAndAppend(i) {
      return new Promise(resolve => {
        let found = false;
        (function tryExt(pos) {
          if (pos >= exts.length) return resolve();
          const ext = exts[pos];
          const path = `${FOLDER}/${i}.${ext}`;
          const img = new Image();
          img.onload = function () {
            if (found) return;
            found = true;
            galleryRow.insertAdjacentHTML("beforeend", cardHTML(path, i));
            resolve();
          };
          img.onerror = function () { tryExt(pos + 1); };
          img.src = path;
        })(0);
      });
    }

    function cardHTML(src, i) {
      return `
      <div class="col-12 col-sm-6 col-md-4 col-lg-4">
        <article class="card g-card" tabindex="0" aria-labelledby="title${i}">
          <div class="g-media">
            <div class="ratio-box">
              <img src="${src}" loading="lazy" alt="">
            </div>
            <div class="g-actions">
              <a href="${src}" class="popup-image btn btn-light shadow-sm" title="">
                <i class="fa-solid fa-magnifying-glass-plus"></i>
              </a>
            </div>
          </div>
        </article>
      </div>`;
    }

    function initMagnific() {
      // Use delegation on the container so it works for dynamic markup
      // This shows images in a gallery (enable gallery:true)
      $('#galleryRow').magnificPopup({
        delegate: 'a.popup-image',
        type: 'image',
        gallery: {
          enabled: true,
          navigateByImgClick: true,
          tPrev: 'Previous (Left arrow)', 
          tNext: 'Next (Right arrow)'
        },
        mainClass: 'mfp-fade',
        removalDelay: 300
      });
    }

    // Load images and init
    $(function () {
      loadImages();
    });
  })(jQuery);